
let currentLevel = 1;
let score = 100;
let startTime = Date.now();

const levels = {
    1: { key: "neo", clue: "Decrypt the passcode hidden in the falling code.", hint: "The chosen one." },
    2: { key: "trinity", clue: "The key is the name of a skilled hacker.", hint: "She follows the chosen one." },
    3: { key: "morpheus", clue: "Who leads the resistance?", hint: "The captain of the Nebuchadnezzar." },
    4: { key: "zion", clue: "The last city of humankind.", hint: "Home of the free." },
    5: { key: "architect", clue: "The creator of the Matrix.", hint: "The father of the Matrix." }
};

function updateLevel() {
    if (currentLevel > Object.keys(levels).length) {
        document.getElementById("terminal").innerHTML = "<h2>ACCESS GRANTED</h2><p>You have successfully hacked the system!</p>";
        return;
    }

    document.getElementById("level").textContent = `Level ${currentLevel}`;
    document.getElementById("clue").textContent = `Clue: ${levels[currentLevel].clue}`;
    document.getElementById("userInput").value = "";
    document.getElementById("message").textContent = "";
}

document.getElementById("hackButton").addEventListener("click", function () {
    const userInput = document.getElementById("userInput").value.trim();
    const levelKey = levels[currentLevel].key;
    const message = document.getElementById("message");

    if (userInput.toLowerCase() === levelKey) {
        currentLevel++;
        updateLevel();
        message.style.color = "#00ff00";
        message.textContent = "ACCESS GRANTED. Proceeding to the next level.";
    } else {
        message.style.color = "#ff0000";
        message.textContent = "ACCESS DENIED. Try again!";
        score -= 5;
        document.getElementById("score").textContent = score;
    }
});

document.getElementById("hintButton").addEventListener("click", function () {
    const message = document.getElementById("message");
    message.style.color = "#ffff00";
    message.textContent = `HINT: ${levels[currentLevel].hint}`;
    score -= 10;
    document.getElementById("score").textContent = score;
});

setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    document.getElementById("timer").textContent = elapsed;
}, 1000);

updateLevel();
